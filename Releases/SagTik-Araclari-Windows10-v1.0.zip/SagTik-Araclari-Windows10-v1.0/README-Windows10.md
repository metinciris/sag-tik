﻿# Sağ Tık Görsel ve PDF Araçları — Windows 10

Windows Gezgini sağ tık menüsüne yalnızca şu dört işlevi ekler:

- PDF etiketlerini oku ve resimleri gerektiğinde 180° döndür
- JPG, JPEG veya PNG görselini AVIF'e dönüştür
- Klasördeki görselleri AVIF'e dönüştür
- Seçili görsellerden tek PDF oluştur

## Önemli uyarı

> **AVIF dönüşümü başarıyla tamamlandığında kaynak JPG, JPEG veya PNG dosyası silinir.**
>
> Tek kopya olan önemli görsellerde kullanmadan önce yedek alın.

## Gereksinimler

- Windows 10
- Python 3
- Python Launcher (`py.exe`)
- Tesseract OCR
- Aşağıdaki Python paketleri:

```bat
py -3 -m pip install opencv-python numpy pytesseract pymupdf pillow pillow-avif-plugin
```

Tesseract kontrolü:

```bat
tesseract --version
```

## Kurulum

1. ZIP dosyasına sağ tıklayın ve **Özellikler** bölümünü açın.
2. Varsa **Engellemeyi kaldır** kutusunu işaretleyip **Uygula** seçin.
3. ZIP'in tamamını bir klasöre çıkarın.
4. `1_Kurulum.cmd` dosyasına çift tıklayın.
5. Başarılı kurulum mesajını bekleyin.

Menüler hemen görünmezse:

1. `Ctrl + Shift + Esc` ile Görev Yöneticisi'ni açın.
2. **Windows Gezgini** üzerine sağ tıklayın.
3. **Yeniden başlat** seçeneğini kullanın.

## Kullanım

### PDF

PDF dosyasına sağ tıklayın:

```text
Etiketleri oku ve resimleri döndür
```

Araç, PDF içindeki görselleri çıkarır; sarı etiket üzerindeki kırmızı numarayı okumaya çalışır ve gerektiğinde resmi 180° döndürür.

### AVIF

Bir JPG, JPEG veya PNG dosyasına sağ tıklayın:

```text
AVIF'e dönüştür (orijinali sil)
```

Bir klasöre sağ tıklayın:

```text
Klasördeki görselleri AVIF'e dönüştür (orijinalleri sil)
```

Klasör işlemi yalnızca seçilen klasörün doğrudan içindeki görselleri işler; alt klasörlere girmez.

### Görsellerden PDF

Bir veya birden fazla JPG, JPEG ya da PNG dosyasını seçip sağ tıklayın:

```text
Seçili görsellerden tek PDF oluştur
```

Görseller dosya adına göre doğal sırada PDF sayfalarına dönüştürülür.

## Kaldırma

`2_Kaldir.cmd` dosyasına çift tıklayın.

Bu işlem:

- Eklenen sağ tık komutlarını kaldırır.
- `%LOCALAPPDATA%\MetinBasitSagTik` klasöründeki kurulu araçları siler.
- Python, Tesseract ve kişisel dosyalarınıza dokunmaz.

## Gizlilik

Tüm işlemler yerel bilgisayarda yapılır. Görseller ve PDF'ler herhangi bir sunucuya yüklenmez.
