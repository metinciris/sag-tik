import os
import re
import sys
import tempfile
import time
import uuid
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

from PIL import Image

SUPPORTED_EXTS = {".jpg", ".jpeg", ".png"}
QUEUE_DIR = Path(tempfile.gettempdir()) / "MetinSagTik_PdfQueue"
LOCK_FILE = QUEUE_DIR / "leader.lock"


def natural_key(path: Path):
    return [int(part) if part.isdigit() else part.lower() for part in re.split(r"(\d+)", path.name)]


def flatten_to_rgb(image: Image.Image) -> Image.Image:
    if image.mode == "RGB":
        return image.copy()
    if image.mode in ("RGBA", "LA") or "transparency" in image.info:
        rgba = image.convert("RGBA")
        background = Image.new("RGB", rgba.size, "white")
        background.paste(rgba, mask=rgba.getchannel("A"))
        return background
    return image.convert("RGB")


def unique_output(parent: Path) -> Path:
    stamp = datetime.now().strftime("%d_%m_%Y__%H_%M_%S")
    candidate = parent / f"Gorseller_{stamp}.pdf"
    number = 2
    while candidate.exists():
        candidate = parent / f"Gorseller_{stamp}_{number}.pdf"
        number += 1
    return candidate


def normalize_path(raw: str) -> Path | None:
    raw = raw.strip().strip('"')
    if not raw:
        return None
    path = Path(raw)
    try:
        path = path.resolve()
    except OSError:
        return None
    if path.is_file() and path.suffix.lower() in SUPPORTED_EXTS:
        return path
    return None


def enqueue(path: Path) -> None:
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    item = QUEUE_DIR / f"{time.time_ns()}_{os.getpid()}_{uuid.uuid4().hex}.txt"
    item.write_text(str(path), encoding="utf-8")


def become_leader() -> bool:
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode("ascii"))
        os.close(fd)
        return True
    except FileExistsError:
        try:
            if time.time() - LOCK_FILE.stat().st_mtime > 15:
                LOCK_FILE.unlink(missing_ok=True)
                return become_leader()
        except OSError:
            pass
        return False


def collect_queue() -> list[Path]:
    time.sleep(1.0)
    files: list[Path] = []
    seen: set[str] = set()
    for item in sorted(QUEUE_DIR.glob("*.txt")):
        try:
            path = normalize_path(item.read_text(encoding="utf-8"))
            if path is not None:
                key = str(path).casefold()
                if key not in seen:
                    seen.add(key)
                    files.append(path)
        except Exception:
            pass
        finally:
            try:
                item.unlink()
            except OSError:
                pass
    return files


def create_pdf(files: list[Path]) -> None:
    root = tk.Tk()
    root.withdraw()
    root.update()

    if not files:
        messagebox.showerror("Görsellerden PDF", "JPG, JPEG veya PNG seçilmedi.")
        return

    files.sort(key=natural_key)
    output = unique_output(files[0].parent)
    pages: list[Image.Image] = []

    try:
        for path in files:
            with Image.open(path) as image:
                pages.append(flatten_to_rgb(image))

        first, *rest = pages
        first.save(
            output,
            "PDF",
            save_all=True,
            append_images=rest,
            resolution=150.0,
            quality=95,
        )
        messagebox.showinfo(
            "Görsellerden PDF",
            f"PDF oluşturuldu:\n\n{output}\n\nSayfa sayısı: {len(pages)}",
        )
    except Exception as exc:
        messagebox.showerror("Görsellerden PDF", f"PDF oluşturulamadı:\n\n{exc}")
    finally:
        for page in pages:
            try:
                page.close()
            except Exception:
                pass


def main() -> None:
    if len(sys.argv) < 2:
        return
    path = normalize_path(sys.argv[1])
    if path is None:
        return

    enqueue(path)
    if not become_leader():
        return

    try:
        files = collect_queue()
    finally:
        try:
            LOCK_FILE.unlink()
        except OSError:
            pass

    create_pdf(files)


if __name__ == "__main__":
    main()
