﻿# Sağ Tık Görsel ve PDF Araçları — Windows 11

Windows 11 sürümü, araçları doğrudan klasik sağ tık menüsünde göstermek için iki aşamalı kurulum içerir:

1. Windows 11 klasik sağ tık menüsünü etkinleştirme
2. Görsel ve PDF araçlarını kurma

Kurulan işlevler:

- PDF etiketlerini oku ve resimleri gerektiğinde 180° döndür
- JPG, JPEG veya PNG görselini AVIF'e dönüştür
- Klasördeki görselleri AVIF'e dönüştür
- Seçili görsellerden tek PDF oluştur

## Önemli uyarı

> **AVIF dönüşümü başarıyla tamamlandığında kaynak JPG, JPEG veya PNG dosyası silinir.**
>
> Tek kopya olan önemli görsellerde kullanmadan önce yedek alın.

## Gereksinimler

- Windows 11
- Python 3
- Python Launcher (`py.exe`)
- Tesseract OCR
- Aşağıdaki Python paketleri:

```bat
py -3 -m pip install opencv-python numpy pytesseract pymupdf pillow pillow-avif-plugin
```

Tesseract kontrolü:

```bat
tesseract --version
```

## Kurulum sırası

### 1. İndirme engelini kaldırın

1. ZIP dosyasına sağ tıklayın.
2. **Özellikler** bölümünü açın.
3. Varsa **Engellemeyi kaldır** kutusunu işaretleyin.
4. **Uygula** ve **Tamam** seçin.
5. ZIP'in tamamını bir klasöre çıkarın.

### 2. Klasik sağ tık menüsünü etkinleştirin

`1_Klasik_SagTik_Ac.reg` dosyasına çift tıklayın ve kayıt defteri uyarılarını onaylayın.

Ardından:

1. `Ctrl + Shift + Esc` ile Görev Yöneticisi'ni açın.
2. **Windows Gezgini** üzerine sağ tıklayın.
3. **Yeniden başlat** seçeneğini kullanın.

Bundan sonra **Daha fazla seçenek göster** adımı olmadan klasik tam menü açılır.

### 3. Sağ tık araçlarını kurun

Daha önce başka bir sürüm kuruluysa önce `3_Kaldir_SagTik_Araclari.cmd` dosyasını çalıştırın.

Ardından `2_Kurulum.cmd` dosyasına çift tıklayın ve başarılı kurulum mesajını bekleyin.

Menüler görünmezse Windows Gezgini'ni bir kez daha yeniden başlatın.

## Kullanım

### PDF

PDF dosyasına sağ tıklayın:

```text
Etiketleri oku ve resimleri döndür
```

### AVIF

Bir JPG, JPEG veya PNG dosyasına sağ tıklayın:

```text
AVIF'e dönüştür (orijinali sil)
```

Bir klasöre sağ tıklayın:

```text
Klasördeki görselleri AVIF'e dönüştür (orijinalleri sil)
```

Klasör işlemi alt klasörlere girmez.

### Görsellerden PDF

Bir veya birden fazla JPG, JPEG ya da PNG dosyasını seçip sağ tıklayın:

```text
Seçili görsellerden tek PDF oluştur
```

## Araçları kaldırma

`3_Kaldir_SagTik_Araclari.cmd` dosyasına çift tıklayın.

Bu işlem araçları kaldırır; klasik Windows 11 sağ tık menüsü ayarını değiştirmez.

## Windows 11'in yeni kısa menüsüne geri dönme

`4_Windows11_Menusune_Don.reg` dosyasına çift tıklayıp uyarıları onaylayın.

Ardından Windows Gezgini'ni yeniden başlatın.

Bu işlem yalnızca Windows 11 menü görünümünü geri getirir; sağ tık araçlarını kaldırmak için ayrıca `3_Kaldir_SagTik_Araclari.cmd` çalıştırılmalıdır.

## Gizlilik

Tüm işlemler yerel bilgisayarda yapılır. Görseller ve PDF'ler herhangi bir sunucuya yüklenmez.
