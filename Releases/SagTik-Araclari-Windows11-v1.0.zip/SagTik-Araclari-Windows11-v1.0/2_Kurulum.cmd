@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Metin Sag Tik Araclari - Kurulum

where py.exe >nul 2>&1
if errorlevel 1 (
    echo.
    echo HATA: Python Launcher ^(py.exe^) bulunamadi.
    echo Python 3 kurulumunu kontrol edin.
    echo.
    pause
    exit /b 1
)

py -3 "%~dp0Kurulum.py"
set "RESULT=%ERRORLEVEL%"

if not "%RESULT%"=="0" (
    echo.
    echo Kurulum tamamlanamadi.
    echo Ekrandaki hata mesajini ve TEMP klasorundeki gunlugu kontrol edin.
    echo.
    pause
)

exit /b %RESULT%
