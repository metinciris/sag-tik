@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Metin Sag Tik Araclari - Kaldirma

for %%E in (.jpg .jpeg .png) do (
  reg delete "HKCU\Software\Classes\SystemFileAssociations\%%E\shell\MetinAvif" /f >nul 2>&1
  reg delete "HKCU\Software\Classes\SystemFileAssociations\%%E\shell\MetinImagesToPdf" /f >nul 2>&1
)
reg delete "HKCU\Software\Classes\SystemFileAssociations\.pdf\shell\MetinPdfEtiket" /f >nul 2>&1
reg delete "HKCU\Software\Classes\Directory\shell\MetinAvif" /f >nul 2>&1
rmdir /s /q "%LOCALAPPDATA%\MetinBasitSagTik" >nul 2>&1

echo Kaldirma tamamlandi.
pause
