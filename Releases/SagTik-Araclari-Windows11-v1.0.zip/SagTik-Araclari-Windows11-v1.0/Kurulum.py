from __future__ import annotations

import os
import shutil
import sys
import tempfile
import traceback
from pathlib import Path


def show_message(title: str, message: str, error: bool = False) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.withdraw()
        root.update()
        if error:
            messagebox.showerror(title, message, parent=root)
        else:
            messagebox.showinfo(title, message, parent=root)
        root.destroy()
    except Exception:
        print(f"{title}: {message}")


def delete_registry_tree(winreg, root, subkey: str) -> None:
    try:
        with winreg.OpenKey(root, subkey, 0, winreg.KEY_READ | winreg.KEY_WRITE) as key:
            children: list[str] = []
            index = 0
            while True:
                try:
                    children.append(winreg.EnumKey(key, index))
                    index += 1
                except OSError:
                    break
        for child in children:
            delete_registry_tree(winreg, root, subkey + "\\" + child)
        winreg.DeleteKey(root, subkey)
    except FileNotFoundError:
        pass


def set_registry_value(winreg, root, subkey: str, name: str, value: str) -> None:
    with winreg.CreateKeyEx(root, subkey, 0, winreg.KEY_WRITE) as key:
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, value)


def quote_command(executable: Path, script: Path) -> str:
    return f'"{executable}" "{script}" "%1"'


def install() -> None:
    if os.name != "nt":
        raise RuntimeError("Bu kurulum yalnizca Windows icindir.")

    import winreg

    source_dir = Path(__file__).resolve().parent
    required_files = [
        "pdf_core.py",
        "avif_core.py",
        "Pdf_Etiket_SagTik.pyw",
        "AVIF_SagTik.pyw",
        "Gorsellerden_PDF.pyw",
    ]

    missing_files = [name for name in required_files if not (source_dir / name).is_file()]
    if missing_files:
        raise RuntimeError("Eksik kurulum dosyalari: " + ", ".join(missing_files))

    missing_modules: list[str] = []
    module_checks = [
        ("cv2", "opencv-python"),
        ("numpy", "numpy"),
        ("pytesseract", "pytesseract"),
        ("fitz", "PyMuPDF"),
        ("PIL", "Pillow"),
        ("pillow_avif", "pillow-avif-plugin"),
    ]
    for module_name, package_name in module_checks:
        try:
            __import__(module_name)
        except Exception:
            missing_modules.append(package_name)

    if missing_modules:
        packages = " ".join(missing_modules)
        raise RuntimeError(
            "Gerekli Python paketleri eksik:\n\n"
            + "\n".join(f"- {name}" for name in missing_modules)
            + "\n\nKomut Istemi'nde su komutu calistirin:\n"
            + f"py -3 -m pip install {packages}"
        )

    if shutil.which("tesseract") is None:
        raise RuntimeError(
            "Tesseract OCR bulunamadi.\n\n"
            "PDF etiket okuma icin Tesseract kurulmus ve PATH'e eklenmis olmalidir.\n"
            "Kontrol komutu: tesseract --version"
        )

    python_exe = Path(sys.executable).resolve()
    pythonw_exe = python_exe.with_name("pythonw.exe")
    if not pythonw_exe.is_file():
        raise RuntimeError(
            "pythonw.exe bulunamadi.\n\n"
            f"Kullanilan Python: {python_exe}\n"
            "Python kurulumunu degistirip standart pythonw.exe bilesenini ekleyin."
        )

    local_app_data = os.environ.get("LOCALAPPDATA")
    if not local_app_data:
        raise RuntimeError("LOCALAPPDATA ortam degiskeni bulunamadi.")

    destination = Path(local_app_data) / "MetinBasitSagTik"
    destination.mkdir(parents=True, exist_ok=True)
    for name in required_files:
        shutil.copy2(source_dir / name, destination / name)

    hkcu = winreg.HKEY_CURRENT_USER

    old_image_keys = [
        "MetinWebPrepare",
        "MetinImagesToPdf",
        "MetinMetadataClean",
        "MetinAvifKeep",
        "MetinAvifDelete",
        "MetinAvif",
    ]
    for extension in (".jpg", ".jpeg", ".png"):
        for key_name in old_image_keys:
            delete_registry_tree(
                winreg,
                hkcu,
                f"Software\\Classes\\SystemFileAssociations\\{extension}\\shell\\{key_name}",
            )

    for key_name in (
        "MetinPdfLabel",
        "MetinPdfToJpg",
        "MetinPdfCompressHigh",
        "MetinPdfCompressEmail",
        "MetinPdfEtiket",
    ):
        delete_registry_tree(
            winreg,
            hkcu,
            f"Software\\Classes\\SystemFileAssociations\\.pdf\\shell\\{key_name}",
        )

    for key_name in (
        "MetinToolbox",
        "MetinPdfEtiket",
        "MetinAvif",
        "MetinFolderCopyName",
        "MetinFolderList",
        "MetinFolderListRecursive",
        "MetinFolderDatedCopy",
        "MetinProjectBackup",
        "MetinFolderWebPrepare",
        "MetinFolderImagesToPdf",
        "MetinFolderMetadataClean",
        "MetinFolderAvifKeep",
        "MetinFolderAvifDelete",
        "MetinFolderPdfLabel",
    ):
        delete_registry_tree(
            winreg,
            hkcu,
            f"Software\\Classes\\Directory\\shell\\{key_name}",
        )

    send_to = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "SendTo" / "Metin Arac Kutusu.lnk"
    try:
        send_to.unlink()
    except FileNotFoundError:
        pass

    pdf_script = destination / "Pdf_Etiket_SagTik.pyw"
    avif_script = destination / "AVIF_SagTik.pyw"
    images_pdf_script = destination / "Gorsellerden_PDF.pyw"

    pdf_key = "Software\\Classes\\SystemFileAssociations\\.pdf\\shell\\MetinPdfEtiket"
    set_registry_value(winreg, hkcu, pdf_key, "", "Etiketleri oku ve resimleri döndür")
    set_registry_value(winreg, hkcu, pdf_key, "Position", "Top")
    set_registry_value(winreg, hkcu, pdf_key, "MultiSelectModel", "Single")
    set_registry_value(winreg, hkcu, pdf_key + "\\command", "", quote_command(pythonw_exe, pdf_script))

    for extension in (".jpg", ".jpeg", ".png"):
        base = f"Software\\Classes\\SystemFileAssociations\\{extension}\\shell"

        avif_key = base + "\\MetinAvif"
        set_registry_value(winreg, hkcu, avif_key, "", "AVIF'e dönüştür (orijinali sil)")
        set_registry_value(winreg, hkcu, avif_key, "Position", "Top")
        set_registry_value(winreg, hkcu, avif_key, "MultiSelectModel", "Single")
        set_registry_value(winreg, hkcu, avif_key + "\\command", "", quote_command(pythonw_exe, avif_script))

        pdf_images_key = base + "\\MetinImagesToPdf"
        set_registry_value(winreg, hkcu, pdf_images_key, "", "Seçili görsellerden tek PDF oluştur")
        set_registry_value(winreg, hkcu, pdf_images_key, "Position", "Top")
        set_registry_value(winreg, hkcu, pdf_images_key, "MultiSelectModel", "Player")
        set_registry_value(
            winreg,
            hkcu,
            pdf_images_key + "\\command",
            "",
            quote_command(pythonw_exe, images_pdf_script),
        )

    folder_key = "Software\\Classes\\Directory\\shell\\MetinAvif"
    set_registry_value(
        winreg,
        hkcu,
        folder_key,
        "",
        "Klasördeki görselleri AVIF'e dönüştür (orijinalleri sil)",
    )
    set_registry_value(winreg, hkcu, folder_key, "Position", "Top")
    set_registry_value(winreg, hkcu, folder_key, "MultiSelectModel", "Single")
    set_registry_value(winreg, hkcu, folder_key + "\\command", "", quote_command(pythonw_exe, avif_script))

    try:
        import ctypes

        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)
    except Exception:
        pass

    show_message(
        "Metin Sağ Tık Araçları",
        "Kurulum tamamlandı.\n\n"
        "Kurulan işlevler:\n"
        "- PDF etiketlerini oku ve resimleri döndür\n"
        "- Görseli AVIF'e dönüştür ve kaynağı sil\n"
        "- Klasördeki görselleri AVIF'e dönüştür ve kaynakları sil\n"
        "- Seçili görsellerden tek PDF oluştur\n\n"
        "Windows 11'de komutlar Daha fazla seçenek göster altında olabilir.",
    )


def main() -> int:
    try:
        install()
        return 0
    except Exception as exc:
        log_path = Path(tempfile.gettempdir()) / "MetinSagTik_Kurulum_Hatasi.txt"
        details = traceback.format_exc()
        try:
            log_path.write_text(details, encoding="utf-8")
        except Exception:
            pass
        show_message(
            "Kurulum başarısız",
            f"{exc}\n\nAyrıntılı günlük:\n{log_path}",
            error=True,
        )
        print(details)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
