﻿METİN SAĞ TIK ARAÇLARI - v6.0
Windows 10 / Windows 11 | 8 Ekim 2026

KURULUM
1. ZIP dosyasının tamamını bir klasöre çıkarın.
2. Gerekli program ve Python paketleri yoksa aşağıdaki komutu kullanın.
3. Kurulum.vbs dosyasına çift tıklayın. Normalde yönetici yetkisi gerekmez.
4. Sağ tık menüleri görünmüyorsa Windows Gezgini'ni yeniden başlatın.
   Windows 11'de menüler "Daha fazla seçenek göster" altında olabilir.

KORUNAN ÜÇ İŞLEV
- PDF: Etiketleri oku ve resimleri döndür.
- JPG/JPEG/PNG: AVIF'e dönüştür (orijinali sil).
- Klasör: Klasördeki görselleri AVIF'e dönüştür (orijinalleri sil).

KALDIRILAN İŞLEVLER
- "Tarihli RAR yap" sağ tık menüsü ve eski kayıtları.
- "Seçili görsellerden tek PDF oluştur" menüsü ve eski kodu.
- MetinTools / MetinToolsV4 adlı bilinen eski kurulum klasörleri.
Var olan RAR, PDF, görsel ve kişisel dosyalar silinmez. Windows'un
"Yol olarak kopyala" özelliği değiştirilmez.

PDF İŞLEME VE GÖRÜNTÜ KALİTESİ
- Her sayfadaki en büyük gömülü görüntü çıkarılır; sayfa yeniden çizilmez.
- Sarı etiket üzerindeki kırmızı sayının okunması denenir (1000-45000).
- Etiket okunursa dosya buna göre adlandırılır, gerekirse 180 derece döner.
- Etiket okunamazsa dosya "sayfa_0001" gibi adlandırılır ve döndürülmez.
- Çıktı resmine kontrast, gama, parlaklık, keskinleştirme, renk
  otomatik ayarı veya başka bir görüntü iyileştirmesi uygulanmaz.
- OCR için geçici etiket alanı işlenir; bu işlenmiş alan resim olarak kaydedilmez.
- Döndürülmeyen JPEG ve PNG dosyaları özgün gömülü verinin
  bayt bayt aynısı olarak kaydedilir, yeniden sıkıştırılmaz.
- 180 derece döndürülen resimler, yeni JPEG kaybı oluşmaması için
  kayıpsız PNG olarak yazılır.
- PDF'nin yanında aynı adlı çıktı klasörü oluşur. Klasör zaten
  varsa "_2", "_3" ekli YENİ klasör oluşur; eski çıktılar silinmez.
- Kaynak PDF'de bulunmayan görüntü ayrıntıları geri getirilemez.

AVIF - ESKİ DAVRANIŞ KORUNUR
- Dönüştürme başarılı olduğunda kaynak JPG/JPEG/PNG dosyası silinir.
- Klasörde yalnızca doğrudan içerilen resimler işlenir; alt klasörler taranmaz.
- AVIF kalite ayarı değişmedi (quality 40, speed 3).
- Önemli görsellerinizi önceden yedekleyin.

GEREKSİNİMLER
- Python 3.9+ ve pythonw.exe, Tesseract OCR (bağımsız Windows uygulaması).
- Tesseract sistem PATH'inde veya Program Files\Tesseract-OCR içinde olmalı.
- ZIP'i çıkardığınız klasörde terminal açıp şunu çalıştırın:
    py -3 -m pip install -r requirements.txt

KALDIRMA
Kaldir.vbs dosyasına çift tıklayın. Menü kayıtları ve kurulu
araç dosyaları silinir; Python, Tesseract ve kişisel veriler silinmez.
Tüm işlemler yerel bilgisayarda yapılır; veriler sunucuya gönderilmez.
