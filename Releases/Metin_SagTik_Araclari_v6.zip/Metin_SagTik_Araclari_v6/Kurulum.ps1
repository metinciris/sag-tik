﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

function Show-Info([string]$Message) {
    [System.Windows.Forms.MessageBox]::Show($Message, 'Metin Sağ Tık Araçları v6',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
}
function Show-Error([string]$Message) {
    [System.Windows.Forms.MessageBox]::Show($Message, 'Metin Sağ Tık Araçları v6',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
}

function Add-PythonCandidate([System.Collections.Generic.List[string]]$List, [string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return }
    $clean = $Path.Trim().Trim('"')
    if ($clean -like '*\WindowsApps\*') { return }
    if ($clean -match 'pythonw\.exe$') {
        $clean = Join-Path (Split-Path $clean -Parent) 'python.exe'
    }
    if ((Test-Path -LiteralPath $clean -PathType Leaf) -and (-not $List.Contains($clean))) {
        [void]$List.Add($clean)
    }
}

function Get-PythonCandidates {
    $list = New-Object 'System.Collections.Generic.List[string]'
    try {
        $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
        if ($launcher) {
            & $launcher.Source -0p 2>$null | ForEach-Object {
                if ($_ -match '([A-Za-z]:\\.*python(?:w)?\.exe)\s*$') {
                    Add-PythonCandidate $list $Matches[1]
                }
            }
        }
    } catch {}

    foreach ($registryRoot in @(
        'HKCU:\Software\Python\PythonCore',
        'HKLM:\Software\Python\PythonCore',
        'HKLM:\Software\WOW6432Node\Python\PythonCore'
    )) {
        if (-not (Test-Path $registryRoot)) { continue }
        try {
            Get-ChildItem $registryRoot -ErrorAction SilentlyContinue | ForEach-Object {
                $installKey = Join-Path $_.PSPath 'InstallPath'
                if (Test-Path $installKey) {
                    $folder = (Get-Item $installKey).GetValue('')
                    if ($folder) {
                        Add-PythonCandidate $list (Join-Path $folder 'python.exe')
                    }
                }
            }
        } catch {}
    }

    Get-Command python.exe -All -ErrorAction SilentlyContinue | ForEach-Object {
        Add-PythonCandidate $list $_.Source
    }
    return $list.ToArray()
}

function Find-Python([string[]]$Candidates, [string]$Imports) {
    foreach ($candidate in $Candidates) {
        try {
            & $candidate -c $Imports *> $null
            if ($LASTEXITCODE -eq 0) { return $candidate }
        } catch {}
    }
    return $null
}

function Get-Pythonw([string]$PythonExe) {
    $exe = Join-Path (Split-Path $PythonExe -Parent) 'pythonw.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
        throw 'pythonw.exe bulunamadı.'
    }
    return $exe
}

function Test-Tesseract {
    if (Get-Command tesseract.exe -ErrorAction SilentlyContinue) { return $true }
    foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) {
        if (-not $base) { continue }
        if (Test-Path -LiteralPath (Join-Path $base 'Tesseract-OCR\tesseract.exe') -PathType Leaf) {
            return $true
        }
    }
    return $false
}

function Remove-RegKey([string]$SubKey) {
    try {
        [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($SubKey, $false)
    } catch {}
}

function Remove-LegacyMenus {
    $imageVerbs = @(
        'MetinWebPrepare', 'MetinImagesToPdf', 'MetinMetadataClean',
        'MetinAvifKeep', 'MetinAvifDelete', 'MetinAvif'
    )
    foreach ($ext in @('.jpg', '.jpeg', '.png')) {
        foreach ($verb in $imageVerbs) {
            Remove-RegKey "Software\Classes\SystemFileAssociations\$ext\shell\$verb"
        }
    }
    foreach ($verb in @(
        'MetinPdfLabel', 'MetinPdfToJpg', 'MetinPdfCompressHigh',
        'MetinPdfCompressEmail', 'MetinPdfEtiket'
    )) {
        Remove-RegKey "Software\Classes\SystemFileAssociations\.pdf\shell\$verb"
    }
    foreach ($verb in @(
        'MetinCopyName', 'MetinCopyStem', 'MetinDatedCopy',
        'MetinSha256', 'MetinToolbox', 'PackToRar'
    )) {
        Remove-RegKey "Software\Classes\*\shell\$verb"
    }
    foreach ($verb in @(
        'MetinToolbox', 'MetinPdfEtiket', 'MetinAvif', 'MetinFolderCopyName',
        'MetinFolderList', 'MetinFolderListRecursive', 'MetinFolderDatedCopy',
        'MetinProjectBackup', 'MetinFolderWebPrepare', 'MetinFolderImagesToPdf',
        'MetinFolderMetadataClean', 'MetinFolderAvifKeep', 'MetinFolderAvifDelete',
        'MetinFolderPdfLabel', 'PackToRar'
    )) {
        Remove-RegKey "Software\Classes\Directory\shell\$verb"
    }
    Remove-RegKey 'Software\Classes\Directory\Background\shell\MetinToolbox'
    Remove-RegKey 'Software\Classes\AllFilesystemObjects\shell\PackToRar'
    Remove-Item (Join-Path $env:APPDATA 'Microsoft\Windows\SendTo\Metin Araç Kutusu.lnk') -Force -ErrorAction SilentlyContinue
}

function Set-Menu([string]$BaseKey, [string]$Id, [string]$Label,
                  [string]$Command, [string]$Icon, [string]$SelectionMode) {
    $key = "$BaseKey\shell\$Id"
    Remove-RegKey $key
    $item = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($key)
    if (-not $item) { throw "Kayit anahtari olusturulamadi: $key" }
    try {
        $item.SetValue('', $Label, [Microsoft.Win32.RegistryValueKind]::String)
        $item.SetValue('Icon', $Icon, [Microsoft.Win32.RegistryValueKind]::String)
        $item.SetValue('Position', 'Top', [Microsoft.Win32.RegistryValueKind]::String)
        $item.SetValue('MultiSelectModel', $SelectionMode, [Microsoft.Win32.RegistryValueKind]::String)
        $cmd = $item.CreateSubKey('command')
        try {
            $cmd.SetValue('', $Command, [Microsoft.Win32.RegistryValueKind]::String)
        } finally { $cmd.Dispose() }
    } finally { $item.Dispose() }
}

try {
    $source = Split-Path -Parent $MyInvocation.MyCommand.Path
    $required = @('pdf_core.py', 'Pdf_Etiket_SagTik.pyw', 'avif_core.py', 'AVIF_SagTik.pyw')
    foreach ($file in $required) {
        if (-not (Test-Path -LiteralPath (Join-Path $source $file) -PathType Leaf)) {
            throw "Dosya eksik: $file. ZIP arsivinin tamamini klasore cikarin."
        }
    }

    $candidates = @(Get-PythonCandidates)
    if ($candidates.Count -eq 0) { throw 'Python 3 kurulu bulunamadi.' }
    $pdfPython = Find-Python $candidates (
        'import sys, tkinter, cv2, numpy, pytesseract, fitz; from PIL import Image; assert sys.version_info >= (3, 9)'
    )
    $avifPython = Find-Python $candidates (
        'import sys, tkinter; from PIL import Image; import pillow_avif; assert sys.version_info >= (3, 9)'
    )
    if (-not $pdfPython) {
        throw 'PDF icin gereken moduller eksik: opencv-python, numpy, pytesseract, pymupdf, pillow.'
    }
    if (-not $avifPython) {
        throw 'AVIF icin gereken moduller eksik: pillow, pillow-avif-plugin.'
    }
    if (-not (Test-Tesseract)) {
        throw 'Tesseract OCR kurulu bulunamadi. PATH veya Program Files/Tesseract-OCR kontrol edin.'
    }

    $pdfPythonw = Get-Pythonw $pdfPython
    $avifPythonw = Get-Pythonw $avifPython
    $installDir = Join-Path $env:LOCALAPPDATA 'MetinBasitSagTik'
    New-Item -Path $installDir -ItemType Directory -Force | Out-Null
    foreach ($file in $required) {
        Copy-Item -LiteralPath (Join-Path $source $file) -Destination (Join-Path $installDir $file) -Force
    }

    # Validate and copy first; remove the old menus only after prerequisites pass.
    Remove-LegacyMenus
    $pdfScript = Join-Path $installDir 'Pdf_Etiket_SagTik.pyw'
    $avifScript = Join-Path $installDir 'AVIF_SagTik.pyw'
    $pdfCommand = '"{0}" "{1}" "%1"' -f $pdfPythonw, $pdfScript
    $avifFilesCommand = '"{0}" "{1}" %*' -f $avifPythonw, $avifScript
    $avifFolderCommand = '"{0}" "{1}" "%1"' -f $avifPythonw, $avifScript
    $pdfIcon = '"{0}",0' -f $pdfPythonw
    $avifIcon = '"{0}",0' -f $avifPythonw

    Set-Menu 'Software\Classes\SystemFileAssociations\.pdf' 'MetinPdfEtiket' `
        'Etiketleri oku ve resimleri döndür' $pdfCommand $pdfIcon 'Single'
    foreach ($ext in @('.jpg', '.jpeg', '.png')) {
        $base = "Software\Classes\SystemFileAssociations\$ext"
        Set-Menu $base 'MetinAvif' "AVIF'e dönüştür (orijinali sil)" $avifFilesCommand $avifIcon 'Player'
    }
    Set-Menu 'Software\Classes\Directory' 'MetinAvif' `
        "Klasördeki görselleri AVIF'e dönüştür (orijinalleri sil)" $avifFolderCommand $avifIcon 'Single'

    # Delete only known old installed scripts/folders, never user documents.
    Remove-Item (Join-Path $installDir 'Gorsellerden_PDF.pyw') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $installDir '__pycache__') -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $env:LOCALAPPDATA 'MetinTools') -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $env:LOCALAPPDATA 'MetinToolsV4') -Recurse -Force -ErrorAction SilentlyContinue

    Show-Info "Kurulum tamamlandı.`n`nPDF: Etiketleri oku ve resimleri döndür (görüntü iyileştirme yok)`nJPG/JPEG/PNG: AVIF'e dönüştür`nKlasör: Görselleri AVIF'e dönüştür`n`nTarihli RAR ve görsellerden tek PDF menüleri kaldırıldı.`nEski sürüm kayıtları temizlendi.`n`nMenüler görünmüyorsa Windows Gezgini'ni yeniden başlatın."
} catch {
    Show-Error ("Kurulum başarısız:`n`n" + $_.Exception.Message)
    exit 1
}
