"""Read red label numbers and export PDF images without tonal adjustments.

Only the temporary OCR crop is thresholded. The exported image is never given
contrast, gamma, brightness, sharpening, saturation or auto-adjustment.
JPEG/PNG source bytes are copied verbatim when no rotation is needed. For a
180-degree rotation, decoded pixels are transposed and stored as lossless PNG.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from io import BytesIO
from pathlib import Path
import re
import shutil

import cv2
import fitz
import numpy as np
import pytesseract
from PIL import Image

LABEL_MIN_DEFAULT = 1000
LABEL_MAX_DEFAULT = 45000

# The only original formats directly saved without any decoding/re-encoding.
DIRECT_COPY_EXTENSIONS = {
    "jpg": ".jpg", "jpeg": ".jpg", "png": ".png",
    "tif": ".tif", "tiff": ".tif", "bmp": ".bmp",
}


@dataclass
class ProcessingResult:
    output_folder: Path
    pdf_pages: int = 0
    saved: int = 0
    rotated: int = 0
    unread: int = 0
    skipped_pages: int = 0
    warnings: list[str] = field(default_factory=list)


def configure_tesseract() -> None:
    """Support standard Windows installations even when PATH is not updated."""
    if shutil.which("tesseract"):
        return
    import os

    for env_name in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
        base = os.environ.get(env_name)
        if not base:
            continue
        exe = Path(base) / "Tesseract-OCR" / "tesseract.exe"
        if exe.is_file():
            pytesseract.pytesseract.tesseract_cmd = str(exe)
            return
    raise RuntimeError(
        "Tesseract OCR bulunamadi. Tesseract kurun ve uygulamayi yeniden deneyin."
    )


def order_points(pts: np.ndarray) -> np.ndarray:
    rect = np.zeros((4, 2), dtype=np.float32)
    sums = pts.sum(axis=1)
    differences = np.diff(pts, axis=1)
    rect[0] = pts[np.argmin(sums)]
    rect[2] = pts[np.argmax(sums)]
    rect[1] = pts[np.argmin(differences)]
    rect[3] = pts[np.argmax(differences)]
    return rect


def extract_number_from_image(img_bgr: np.ndarray) -> int | None:
    """OCR-only transformations on a temporary crop, never on the output."""
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    yellow = cv2.inRange(
        hsv,
        np.array([20, 100, 100], dtype=np.uint8),
        np.array([30, 255, 255], dtype=np.uint8),
    )
    contours, _ = cv2.findContours(yellow, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    contour = max(contours, key=cv2.contourArea)
    box = order_points(cv2.boxPoints(cv2.minAreaRect(contour)))
    tl, tr, br, bl = box
    max_width = max(int(np.linalg.norm(br - bl)), int(np.linalg.norm(tr - tl)))
    max_height = max(int(np.linalg.norm(tr - br)), int(np.linalg.norm(tl - bl)))
    if min(max_width, max_height) < 20:
        return None

    destination = np.array(
        [[0, 0], [max_width - 1, 0], [max_width - 1, max_height - 1], [0, max_height - 1]],
        dtype=np.float32,
    )
    transform = cv2.getPerspectiveTransform(box, destination)
    crop = cv2.warpPerspective(img_bgr, transform, (max_width, max_height))
    hsv_crop = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    red1 = cv2.inRange(
        hsv_crop, np.array([0, 70, 50], np.uint8), np.array([10, 255, 255], np.uint8)
    )
    red2 = cv2.inRange(
        hsv_crop, np.array([170, 70, 50], np.uint8), np.array([180, 255, 255], np.uint8)
    )
    red_mask = cv2.bitwise_or(red1, red2)
    red_digits = cv2.bitwise_and(crop, crop, mask=red_mask)
    gray = cv2.cvtColor(red_digits, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    recognized = pytesseract.image_to_string(binary, config="--oem 3 --psm 6 outputbase digits")
    digits = "".join(char for char in recognized if char.isdigit())
    return int(digits) if digits else None


def find_label_and_orientation(
    img_bgr: np.ndarray, min_number: int, max_number: int
) -> tuple[int | None, bool]:
    """Return detected label and whether a 180-degree rotation is necessary."""
    normal = extract_number_from_image(img_bgr)
    if normal is not None and min_number <= normal <= max_number:
        return normal, False

    upside_down = cv2.rotate(img_bgr, cv2.ROTATE_180)
    inverted = extract_number_from_image(upside_down)
    if inverted is not None and min_number <= inverted <= max_number:
        return inverted, True
    return None, False


def _rgb_array_for_ocr(raw: bytes, doc: fitz.Document, xref: int) -> np.ndarray:
    """Decode to BGR solely for label recognition; do not save this array."""
    try:
        with Image.open(BytesIO(raw)) as image:
            rgb = np.asarray(image.convert("RGB"))
        return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    except (OSError, ValueError):
        # Rare PDF image formats that Pillow does not directly decode.
        pix = fitz.Pixmap(doc, xref)
        if pix.n != 3 or pix.alpha:
            pix = fitz.Pixmap(fitz.csRGB, pix)
        rgb = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, 3)
        return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


def _png_bytes(raw: bytes, doc: fitz.Document, xref: int, rotate: bool) -> bytes:
    """PNG saves decoded pixels without JPEG re-compression or tonal changes."""
    try:
        with Image.open(BytesIO(raw)) as image:
            # JPEG sources are RGB/L; PNG handles these without any color changes.
            if image.mode in ("CMYK", "YCbCr", "LAB", "HSV"):
                image = image.convert("RGB")
            if rotate:
                image = image.transpose(Image.Transpose.ROTATE_180)
            out = BytesIO()
            save_options = {"format": "PNG", "compress_level": 6}
            if image.info.get("icc_profile"):
                save_options["icc_profile"] = image.info["icc_profile"]
            image.save(out, **save_options)
            return out.getvalue()
    except (OSError, ValueError):
        pix = fitz.Pixmap(doc, xref)
        if pix.colorspace not in (fitz.csRGB, fitz.csGRAY):
            pix = fitz.Pixmap(fitz.csRGB, pix)
        if not rotate:
            return pix.tobytes("png")
        with Image.open(BytesIO(pix.tobytes("png"))) as image:
            out = BytesIO()
            image.transpose(Image.Transpose.ROTATE_180).save(out, "PNG", compress_level=6)
            return out.getvalue()


def _unique_directory(pdf_path: Path) -> Path:
    safe_stem = re.sub(r'[<>:"/\\|?*]+', "_", pdf_path.stem).strip(" .") or "pdf_cikti"
    for number in range(1, 10000):
        name = safe_stem if number == 1 else f"{safe_stem}_{number}"
        path = pdf_path.parent / name
        try:
            path.mkdir(parents=False, exist_ok=False)
            return path
        except FileExistsError:
            continue
    raise RuntimeError("Bos cikti klasoru adi bulunamadi.")


def _unique_path(folder: Path, stem: str, extension: str) -> Path:
    path = folder / (stem + extension)
    suffix = 2
    while path.exists():
        path = folder / f"{stem}_{suffix}{extension}"
        suffix += 1
    return path


def process_single_pdf(
    pdf_path: str | Path,
    label_min: int = LABEL_MIN_DEFAULT,
    label_max: int = LABEL_MAX_DEFAULT,
) -> ProcessingResult:
    """Extract the largest embedded image per PDF page, preserving image quality.

    A new output directory is always created: existing output is never erased.
    Rotated images are written as lossless PNG; non-rotated JPEG/PNG/etc. files
    keep exactly the embedded source bytes when their format supports it.
    """
    source = Path(pdf_path).resolve()
    if not source.is_file() or source.suffix.lower() != ".pdf":
        raise ValueError("Gecerli bir PDF dosyasi secilmeli.")
    if label_min > label_max:
        raise ValueError("Etiket numara araligi hatali.")

    configure_tesseract()
    with fitz.open(str(source)) as doc:
        if doc.needs_pass:
            raise ValueError("Sifreli PDF desteklenmiyor.")
        result = ProcessingResult(output_folder=_unique_directory(source), pdf_pages=len(doc))
        try:
            for index in range(len(doc)):
                page = doc[index]
                images = page.get_images(full=True)
                if not images:
                    result.skipped_pages += 1
                    result.warnings.append(f"Sayfa {index + 1}: gomulu resim yok.")
                    continue

                # Same policy as the earlier tool: one largest image per page.
                best = max(images, key=lambda info: int(info[2]) * int(info[3]))
                xref = best[0]
                extracted = doc.extract_image(xref)
                if not extracted or not extracted.get("image"):
                    result.skipped_pages += 1
                    result.warnings.append(f"Sayfa {index + 1}: resim alinamadi.")
                    continue

                raw = extracted["image"]
                extension = str(extracted.get("ext", "")).lower().lstrip(".")
                pixels_for_ocr = _rgb_array_for_ocr(raw, doc, xref)
                number, needs_rotation = find_label_and_orientation(
                    pixels_for_ocr, label_min, label_max
                )

                stem = str(number) if number is not None else f"sayfa_{index + 1:04d}"
                if needs_rotation or extension not in DIRECT_COPY_EXTENSIONS:
                    content = _png_bytes(raw, doc, xref, needs_rotation)
                    suffix = ".png"
                else:
                    content = raw  # Exactly the bytes extracted from the PDF.
                    suffix = DIRECT_COPY_EXTENSIONS[extension]

                destination = _unique_path(result.output_folder, stem, suffix)
                destination.write_bytes(content)
                result.saved += 1
                if needs_rotation:
                    result.rotated += 1
                if number is None:
                    result.unread += 1
            return result
        except BaseException:
            # Preserve any successfully extracted images for troubleshooting.
            raise
