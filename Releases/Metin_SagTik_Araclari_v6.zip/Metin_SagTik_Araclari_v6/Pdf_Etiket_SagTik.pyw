"""Windows Explorer right-click entry point (silent pythonw.exe launcher)."""

from pathlib import Path
import sys
import tkinter as tk
from tkinter import messagebox

import pdf_core


def main() -> None:
    root = tk.Tk()
    root.withdraw()
    root.update()

    if len(sys.argv) != 2:
        messagebox.showerror("PDF etiket aracı", "İşlenecek PDF yolu alınamadı.")
        return

    source = Path(sys.argv[1])
    try:
        status = pdf_core.process_single_pdf(source)
    except Exception as exc:
        messagebox.showerror("PDF etiket aracı", f"PDF işlenemedi:\n\n{exc}")
        return

    warnings = "\n".join(status.warnings[:5])
    if len(status.warnings) > 5:
        warnings += f"\n... ve {len(status.warnings) - 5} ek uyarı"
    messagebox.showinfo(
        "PDF işlemi tamamlandı",
        f"Kaydedilen resim: {status.saved}\n"
        f"180° döndürülen: {status.rotated}\n"
        f"Etiketi okunamayan: {status.unread}\n"
        f"Görsel bulunamayan sayfa: {status.skipped_pages}\n\n"
        f"Çıktı klasörü:\n{status.output_folder}"
        + (f"\n\n{warnings}" if warnings else ""),
    )


if __name__ == "__main__":
    main()
