﻿$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms

function Remove-RegKey([string]$SubKey) {
    try { [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($SubKey, $false) } catch {}
}

foreach ($ext in @('.jpg', '.jpeg', '.png')) {
    foreach ($verb in @('MetinAvif', 'MetinImagesToPdf', 'MetinAvifKeep', 'MetinAvifDelete')) {
        Remove-RegKey "Software\Classes\SystemFileAssociations\$ext\shell\$verb"
    }
}
foreach ($verb in @('MetinPdfEtiket', 'MetinPdfLabel')) {
    Remove-RegKey "Software\Classes\SystemFileAssociations\.pdf\shell\$verb"
}
foreach ($verb in @('MetinPdfEtiket', 'MetinAvif', 'PackToRar')) {
    Remove-RegKey "Software\Classes\Directory\shell\$verb"
}
Remove-RegKey 'Software\Classes\*\shell\PackToRar'
Remove-RegKey 'Software\Classes\AllFilesystemObjects\shell\PackToRar'

foreach ($dir in @('MetinBasitSagTik', 'MetinTools', 'MetinToolsV4')) {
    Remove-Item (Join-Path $env:LOCALAPPDATA $dir) -Recurse -Force -ErrorAction SilentlyContinue
}

[System.Windows.Forms.MessageBox]::Show(
    "Sağ tık araçları ve eski bilinen kayıtlar kaldırıldı.`nWindows Gezgini'ni yeniden başlatmanız gerekebilir.", 'Metin Sağ Tık Araçları v6',
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Information
) | Out-Null
